package hello;

import java.util.List;

public class ListaVO {

	private List<Quote2> quotes;

	public List<Quote2> getQuotes() {
		return quotes;
	}

	public void setQuotes(List<Quote2> quotes) {
		this.quotes = quotes;
	}
	
	
}
