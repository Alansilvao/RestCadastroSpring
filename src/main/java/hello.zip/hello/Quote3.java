package hello;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Quote3 {
	
	private String id;
	private String max_temp;
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMax_temp() {
		return max_temp;
	}
	public void setMax_temp(String max_temp) {
		this.max_temp = max_temp;
	}
	@Override
	public String toString() {
		return "Quote3 [id=" + id + ", max_temp=" + max_temp + "]";
	}
	
	
	
	
	
	
	
}
